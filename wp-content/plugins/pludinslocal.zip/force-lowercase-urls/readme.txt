=== Force Lowercase URLs ===
Contributors: stormuk
Donate link: http://www.stormconsultancy.co.uk/
Tags: redirects, 301
Requires at least: 3.4
Tested up to: 3.4.2
Stable tag: 1.0
License: MIT
License URI: http://opensource.org/licenses/MIT

Perform a 301 redirect from an uppercase URL to the lowercase version for all non-admin, non-file URLs


== Installation ==

Download and upload to a force-lowercase-urls directory inside wp-content/plugins.

Go to the plugins page and activate it.

== Changelog ==

= 1.0 =
* First version