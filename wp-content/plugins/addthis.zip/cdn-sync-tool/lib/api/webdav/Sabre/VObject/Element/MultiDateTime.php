<?php

/**
 * Multi-DateTime property
 *
 * This class got renamed to Sabre_VObject_Property_MultiDateTime
 *
 * @package Sabre
 * @subpackage VObject
 * @copyright Copyright (C) 2007-2012 Rooftop Solutions. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/)
 * @license http://code.google.com/p/sabredav/wiki/License Modified BSD License
 * @deprecated
 */
class Sabre_VObject_Element_MultiDateTime extends Sabre_VObject_Property_MultiDateTime {

}
