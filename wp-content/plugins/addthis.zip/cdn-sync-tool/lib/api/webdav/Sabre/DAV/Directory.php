<?php

/**
 * Directory class
 *
 * This class is now deprecated in favor of the Sabre_DAV_Collection class.
 *
 * @package Sabre
 * @subpackage DAV
 * @deprecated Use Sabre_DAV_Collection instead
 * @copyright Copyright (C) 2007-2012 Rooftop Solutions. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 * @license http://code.google.com/p/sabredav/wiki/License Modified BSD License
 */
abstract class Sabre_DAV_Directory extends Sabre_DAV_Collection {
}

